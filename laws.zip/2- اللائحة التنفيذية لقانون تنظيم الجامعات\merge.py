import json
import os

folder_path = "."

# قراءة ملفات HTML وترتيبها
html_files = sorted(
    [f for f in os.listdir(folder_path) if f.endswith('.html')],
    key=lambda x: int(''.join(filter(str.isdigit, x))) if any(c.isdigit() for c in x) else 0
)

# دمج مباشر
all_content = []
for i, filename in enumerate(html_files, 1):
    with open(filename, 'r', encoding='utf-8') as f:
        all_content.append({
            "file_number": i,
            "filename": filename,
            "content": f.read()
        })

# حفظ الملف النهائي
with open("all_merged.json", 'w', encoding='utf-8') as f:
    json.dump(all_content, f, ensure_ascii=False, indent=2)

print(f"✅ تم دمج {len(html_files)} ملف!")
print("📁 الملف النهائي: all_merged.json")
